var map = L.map('map').setView([37.9838, 23.7275], 13); // Example: Athens coords

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19
}).addTo(map);

L.marker([37.9838, 23.7275]).addTo(map)
    .bindPopup("Our University Campus")
    .openPopup();
